---
title: "Recipes"
date: 2024-01-04
draft: false
---

# Recipes

Welcome to our collection of delicious recipes!
